// src/pages/KYCCallbackPage.tsx
import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const KYCCallbackPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const sessionId = params.get('session_id');

    if (sessionId) {
      // You can send sessionId to your backend for verification if needed
      console.log('Stripe Identity session completed:', sessionId);
      
      // Optionally: trigger user state update or fetch updated KYC status
      
      navigate('/dashboard'); // or wherever you want after completion
    } else {
      alert('Missing session ID.');
      navigate('/');
    }
  }, [location, navigate]);

  return (
    <div className="text-center pt-20 text-xl text-gray-300">
      Finalizing KYC Verification...
    </div>
  );
};

export default KYCCallbackPage;
