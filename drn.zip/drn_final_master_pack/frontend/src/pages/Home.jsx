export default function Home() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold">Welcome to DRN Token Sale</h1>
      <p>Buy DRN Tokens, access the Dronera platform, and join the future of UAV tech.</p>
    </div>
  );
}
