# 🎉 Welcome to Dronera — Your DRN Token Contract

Thank you for joining Dronera!

**Wallet Address:** {{ wallet_address }}

**Amount Purchased:** {{ token_amount }} DRN

For any questions, contact us at [support@dronera.eu](mailto:support@dronera.eu).

Best regards,  
Dronera Team
