# DRN Token Sale Starter Pack

## Setup

1. Install dependencies: `npm install`
2. Setup Supabase: `supabase init && supabase db push`
3. Deploy smart contracts: `npx hardhat deploy`
4. Run frontend: `npm run dev`
5. Configure `.env` with API keys (Stripe, Supabase, Wallet, SMTP)

## MetaMask Integration

- Connect wallet using ethers.js
- Buy tokens via smart contract (enforcing on-chain KYC)
- Optional backend listener to update Supabase DB with on-chain events
